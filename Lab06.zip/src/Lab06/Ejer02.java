/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Lab06;

import java.util.Scanner;

public class Ejer02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TablaHash tabla = new TablaHash();

        System.out.print("Ingrese la cantidad de estudiantes: ");
        int cantidad = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < cantidad; i++) {
            System.out.println("Estudiante " + (i + 1));
            System.out.print("Clave (7 digitos): ");
            int clave = sc.nextInt();
            sc.nextLine();

            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            int parte1 = clave / 1000;    
            int parte2 = clave % 1000;   
            int suma = parte1 + parte2;

            int posicion = suma % cantidad;

            tabla.insertarElemento(posicion, "Clave " + clave + " - " + nombre);
        }

        System.out.println("\nContenido de la tabla:");
        tabla.imprimir();
    }
}
