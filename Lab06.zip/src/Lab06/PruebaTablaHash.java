package Lab06;

public class PruebaTablaHash {
    public static void main(String[] args) {
        TablaHash mitabla = new TablaHash();
        mitabla.insertarElemento(1, "UNO");
        mitabla.insertarElemento(2, "two");
        mitabla.insertarElemento(3, "tres");
        mitabla.imprimir();
        mitabla.contarElementos();
        mitabla.buscar(3);

        mitabla.limpiar();
        mitabla.imprimir();

        mitabla.insertarElemento("uno", "1");
        mitabla.insertarElemento("tress", "33");
        mitabla.insertarElemento("cinco", "5");

        mitabla.imprimir();
        mitabla.eliminar("tress");
        
        mitabla.imprimir();
    }
}
