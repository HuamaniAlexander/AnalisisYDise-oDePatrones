package Lab06;

import java.util.Scanner;

public class Ejer01 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        TablaHash tabla = new TablaHash();

        System.out.print("Ingrese la cantidad de colaboradores: ");
        int cantidad = sc.nextInt();
        sc.nextLine();

        int tamañoTabla = cantidad;

        for (int i = 0; i < cantidad; i++) {
            System.out.println("Colaborador " + (i + 1));
            System.out.print("Clave (3 digitos): ");
            int clave = sc.nextInt();
            sc.nextLine();

            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            int indice = clave % tamañoTabla;
            tabla.insertarElemento(indice, "Clave " + clave + " - " + nombre);
        }

        System.out.println("\nContenido de la tabla:");
        tabla.imprimir();
    }
}
