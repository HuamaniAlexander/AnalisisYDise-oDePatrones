package analisis;

import java.util.Scanner;


public class Ejercicio2 {

   
    public static void main(String[] args) {
        
        TablaHash mitabla=new TablaHash();
        
        Scanner lector = new Scanner(System.in);
        String[] n = new String[3];
        int[] c = new int[3];
        
        for(int i=0;i<3;i++){
        System.out.println("Ingrese Nombre");
        n[i]=lector.nextLine();
        System.out.println("Ingese la Clave");
        c[i]=lector.nextInt();
        lector.nextLine();
        
        if(c[i]%2!=0){
            c[i]=c[i]*10;
        }
        double d=c[i];
        double s=0;
        while(s<999){
            d=d/10;
            s=Math.floor(d);
            
            
        }
            System.out.println(s);
        
            
        int t=c[i]%3;
        mitabla.insertarElemento(t, n[i]);
        }
        
        mitabla.imprimir();
        
    }
    
}
