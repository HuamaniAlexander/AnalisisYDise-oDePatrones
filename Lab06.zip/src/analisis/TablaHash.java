package analisis;
import java.util.*;

public class TablaHash {
  Hashtable tabla;
  
  public TablaHash(){
      tabla = new Hashtable();
  }
  
  public void insertarElemento(Object posicion, Object valor){
      tabla.put(posicion, valor);
  }
  
  public void eliminar(Object posicion){
      tabla.remove(posicion);
  }
  
  public void buscar(Object posicion){
      if(tabla.containsKey(posicion))
          System.out.println("El valor en la posición "+posicion+" es:");
       else 
          System.out.println("El valor no existe en la tabla");
  }
  public void limpiar(){
      tabla.clear();
  }
  
  public void contarElementos(){
      System.out.println("El numero de elementos es: "+tabla.size());
  }
  
  public boolean estaVacia(){
      return tabla.isEmpty();
  }
  
  public void imprimir(){
      Enumeration e = tabla.keys();
      Object obj;
      if(estaVacia()) {
          System.out.println(" Tabla vacia");
          return;
      }
      while (e.hasMoreElements())
      {
          obj = e.nextElement();
          System.out.println(" Posicion "+obj+": "+tabla.get(obj));
      }
  }
  
    
}
