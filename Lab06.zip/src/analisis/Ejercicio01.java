package analisis;

import java.util.Scanner;
public class Ejercicio01 {
    public static void main(String[] args) {
        TablaHash mitabla=new TablaHash();
        /*
       mitabla.insertarElemento(1, "UNO");
       mitabla.insertarElemento(2, "TWO");
       mitabla.insertarElemento(3, "THREE");
       mitabla.imprimir();
       mitabla.contarElementos();
       mitabla.buscar(3);
       
       mitabla.limpiar();
       mitabla.imprimir();
       
       mitabla.insertarElemento("uno", "1");
       mitabla.insertarElemento("tress", "33");
       mitabla.insertarElemento("cinco", "5");
       
       mitabla.imprimir();
       mitabla.eliminar("tress");
       
       mitabla.imprimir();
        */
        
        Scanner lector = new Scanner(System.in);
        String[] n = new String[3];
        int[] c = new int[3];
        
        for(int i=0;i<3;i++){
        System.out.println("Ingrese Nombre");
        n[i]=lector.nextLine();
        System.out.println("Ingese la Clave");
        c[i]=lector.nextInt();
        lector.nextLine();
        
        int t=c[i]%3;
        mitabla.insertarElemento(t, n[i]);
        }
        
        mitabla.imprimir();
        
    }
}
