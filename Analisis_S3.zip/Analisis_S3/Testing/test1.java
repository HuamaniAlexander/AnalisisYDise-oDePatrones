package Testing;

import java.util.Arrays;

public class test1 {
    
    // Función para mezclar dos subarreglos
    public static void mezclar(int[] arr, int inicio, int medio, int fin) {
        int n1 = medio - inicio + 1;
        int n2 = fin - medio;

        int[] izquierdo = new int[n1];
        int[] derecho = new int[n2];

        for (int i = 0; i < n1; i++)
            izquierdo[i] = arr[inicio + i];
        for (int j = 0; j < n2; j++)
            derecho[j] = arr[medio + 1 + j];

        int i = 0, j = 0, k = inicio;
        while (i < n1 && j < n2) {
            if (izquierdo[i] <= derecho[j]) {
                arr[k] = izquierdo[i];
                i++;
            } else {
                arr[k] = derecho[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = izquierdo[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = derecho[j];
            j++;
            k++;
        }
    }

    // Ordenamiento por mezcla directa iterativo
    public static void mezclaDirectaIterativa(int[] arr) {
        int n = arr.length;
        for (int tamaño = 1; tamaño < n; tamaño *= 2) {
            for (int inicio = 0; inicio < n - tamaño; inicio += 2 * tamaño) {
                int medio = inicio + tamaño - 1;
                int fin = Math.min(inicio + 2 * tamaño - 1, n - 1);
                mezclar(arr, inicio, medio, fin);
            }
        }
    }

    public static void main(String[] args) {
        int[] arr = {22, 6, 25, 48, 32, 5, 12, 20, 31, 35};
        System.out.println("Arreglo original: " + Arrays.toString(arr));
        mezclaDirectaIterativa(arr);
        System.out.println("Arreglo ordenado: " + Arrays.toString(arr));
    }
}
