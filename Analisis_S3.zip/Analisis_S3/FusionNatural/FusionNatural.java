package FusionNatural;
import java.util.*;

public class FusionNatural {

    public static void main(String[] args) {
        List<Integer> listado = Arrays.asList(34, 7, 23, 32, 5, 62, 32, 7, 23, 5, 62, 34);

        List<Integer> listadoOrdenado = OrdenamientoExternoFusionNatural(listado);

        System.out.println("Listado ordenado: " + listadoOrdenado);
    }

    public static List<List<Integer>> DividirEnSecuenciasNaturales(List<Integer> listado) {
        List<List<Integer>> secuencias = new ArrayList<>();
        List<Integer> secuencia_actual = new ArrayList<>();

        secuencia_actual.add(listado.get(0));

        for (int i = 1; i < listado.size(); i++) {
            if (listado.get(i) >= listado.get(i - 1)) {
                secuencia_actual.add(listado.get(i));
            } else {
                secuencias.add(secuencia_actual);
                secuencia_actual = new ArrayList<>();
                secuencia_actual.add(listado.get(i));
            }
        }

        secuencias.add(secuencia_actual);
        return secuencias;
    }

    public static List<Integer> Mezclar(List<List<Integer>> secuencias) {
        while (secuencias.size() > 1) {
            List<List<Integer>> nuevas_secuencias = new ArrayList<>();

            for (int i = 0; i < secuencias.size(); i += 2) {
                if (i + 1 < secuencias.size()) {
                    nuevas_secuencias.add(mezclar(secuencias.get(i), secuencias.get(i + 1)));
                } else {
                    nuevas_secuencias.add(secuencias.get(i));
                }
            }

            secuencias = nuevas_secuencias;
        }

        return secuencias.get(0);
    }

    private static List<Integer> mezclar(List<Integer> a, List<Integer> b) {
        List<Integer> resultado = new ArrayList<>();
        int i = 0, j = 0;

        while (i < a.size() && j < b.size()) {
            if (a.get(i) <= b.get(j)) {
                resultado.add(a.get(i++));
            } else {
                resultado.add(b.get(j++));
            }
        }

        while (i < a.size()) resultado.add(a.get(i++));
        while (j < b.size()) resultado.add(b.get(j++));

        return resultado;
    }

    public static List<Integer> OrdenamientoExternoFusionNatural(List<Integer> listado) {
        List<List<Integer>> secuencias = DividirEnSecuenciasNaturales(listado);
        List<Integer> listado_ordenado = Mezclar(secuencias);
        return listado_ordenado;
    }
}
