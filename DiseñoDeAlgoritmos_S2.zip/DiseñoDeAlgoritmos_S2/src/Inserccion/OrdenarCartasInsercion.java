package Inserccion;

public class OrdenarCartasInsercion {
    public static void main(String[] args) {
        int[] cartas = {8, 3, 5, 4, 2};

        // Algoritmo de inserción
        for (int i = 1; i < cartas.length; i++) {
            int clave = cartas[i];
            int j = i - 1;

            // Mover los elementos mayores a la derecha
            while (j >= 0 && cartas[j] > clave) {
                cartas[j + 1] = cartas[j];
                j--;
            }

            // Insertar la carta en la posición correcta
            cartas[j + 1] = clave;
        }

        // Mostrar el resultado
        System.out.println("Cartas ordenadas:");
        for (int carta : cartas) {
            System.out.print(carta + " ");
        }
    }
}

