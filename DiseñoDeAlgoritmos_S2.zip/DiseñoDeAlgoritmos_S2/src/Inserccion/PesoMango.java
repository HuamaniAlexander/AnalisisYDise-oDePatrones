package Inserccion;

public class PesoMango {
    public static void main(String[] args) {
        int[] mango = {100, 120, 80, 150, 110}; // pesos en gr

        for (int i = 1; i < mango.length; i++) {
            int clave = mango[i];
            int j = i - 1;

            while (j >= 0 && mango[j] > clave) {
                mango[j + 1] = mango[j];
                j--;
            }

            mango[j + 1] = clave;
        }

        System.out.println("Mango ordenados por peso:");
        for (int s : mango) {
            System.out.print(s + "gr ");
        }
    }
}