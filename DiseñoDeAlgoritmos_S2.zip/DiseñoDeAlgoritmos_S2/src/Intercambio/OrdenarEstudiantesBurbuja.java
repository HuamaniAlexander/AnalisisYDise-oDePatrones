package Intercambio;

public class OrdenarEstudiantesBurbuja {
    public static void main(String[] args) {
        int[] alturas = {160, 175, 150, 180, 165};

        // Algoritmo de burbuja
        for (int i = 0; i < alturas.length - 1; i++) {
            for (int j = 0; j < alturas.length - 1 - i; j++) {
                if (alturas[j] > alturas[j + 1]) {
                    // Intercambio
                    int temp = alturas[j];
                    alturas[j] = alturas[j + 1];
                    alturas[j + 1] = temp;
                }
            }
        }

        // Mostrar resultado
        System.out.println("Estudiantes ordenados por altura:");
        for (int altura : alturas) {
            System.out.print(altura + " ");
        }
    }
}
