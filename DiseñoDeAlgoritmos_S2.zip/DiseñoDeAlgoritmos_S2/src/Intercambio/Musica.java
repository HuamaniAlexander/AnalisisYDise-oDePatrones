package Intercambio;

public class Musica {
    public static void main(String[] args) {
        int[] duraciones = {4, 2, 5, 3}; // en minutos

        for (int i = 0; i < duraciones.length - 1; i++) {
            for (int j = 0; j < duraciones.length - 1 - i; j++) {
                if (duraciones[j] > duraciones[j + 1]) {
                    // Intercambio
                    int temp = duraciones[j];
                    duraciones[j] = duraciones[j + 1];
                    duraciones[j + 1] = temp;
                }
            }
        }

        System.out.println("Canciones ordenadas por duracion:");
        for (int d : duraciones) {
            System.out.print(d + " min ");
        }
    }
}

