package Seleccion;

public class OrdenarLibrosSeleccion {
    public static void main(String[] args) {
        String[] libros = {"Zorro", "Ana", "Luna", "Carlos", "Mario"};

        // Algoritmo de selección
        for (int i = 0; i < libros.length - 1; i++) {
            int indiceMinimo = i;

            // Buscar el libro con el título más pequeño (alfabéticamente)
            for (int j = i + 1; j < libros.length; j++) {
                if (libros[j].compareToIgnoreCase(libros[indiceMinimo]) < 0) {
                    indiceMinimo = j;
                }
            }

            // Intercambiar
            String temp = libros[indiceMinimo];
            libros[indiceMinimo] = libros[i];
            libros[i] = temp;
        }

        // Mostrar libros ordenados
        System.out.println("Libros ordenados alfabeticamente:");
        for (String libro : libros) {
            System.out.println(libro);
        }
    }
}

