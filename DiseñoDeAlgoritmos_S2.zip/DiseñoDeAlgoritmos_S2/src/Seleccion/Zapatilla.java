package Seleccion;

public class Zapatilla {
    public static void main(String[] args) {
        int[] tallas = {42, 38, 44, 40, 36};

        for (int i = 0; i < tallas.length - 1; i++) {
            int indiceMinimo = i;

            for (int j = i + 1; j < tallas.length; j++) {
                if (tallas[j] < tallas[indiceMinimo]) {
                    indiceMinimo = j;
                }
            }

            // Intercambiar
            int temp = tallas[indiceMinimo];
            tallas[indiceMinimo] = tallas[i];
            tallas[i] = temp;
        }

        System.out.println("Tallas de zapatillas ordenadas:");
        for (int t : tallas) {
            System.out.print(t + " ");
        }
    }
}
