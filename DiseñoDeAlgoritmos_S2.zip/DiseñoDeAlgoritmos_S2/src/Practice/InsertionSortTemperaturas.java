package Practice;

public class InsertionSortTemperaturas {
    public static void main(String[] args) {
        double[] temperaturas = {12.5,11.7,18.2,10.6,17.2,16.4};
        
        System.out.println("Temperaturas desordenadas");
        for (double t : temperaturas){
            System.out.print(t + " ");
        }
        
        for (int i = 1 ; i < temperaturas.length; i++){
            double actual = temperaturas[i];
            int j = i-1;
            
            while (j >= 0 && temperaturas[j] > actual){
                temperaturas[j+1] = temperaturas[j];
                j--;
            }
            temperaturas[j+1] = actual;
        }
        
        System.out.println("Temperaturas ordenadas");
        for (double t : temperaturas){
            System.out.print(t +" ");
        }
    }
}
