package Practice;

public class SelectionSortEdades {
    public static void main(String[] args) {
        int[] edades = {19,22,11,16,23,12};
        
        System.out.println("Edades antes de ordenar:");
        for (int e : edades){
            System.out.print(e + " ");
        }
        
        for (int i = 0; i< edades.length - 1; i++){
            int minIndice = i;
            for (int j = i + 1; j < edades.length; j++){
                if(edades[j] < edades[minIndice]){
                    minIndice = j;
                }
            }
            
            int temp = edades[minIndice];
            edades[minIndice] = edades[i];
            edades[i]=temp;
        }
        System.out.println("\nEdades despues de ordenar: ");
        
        for (int e : edades){
            System.out.print(e + " ");
        }
    }
}
