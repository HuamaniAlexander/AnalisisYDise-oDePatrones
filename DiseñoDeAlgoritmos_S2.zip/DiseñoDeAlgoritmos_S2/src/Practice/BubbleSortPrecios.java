package Practice;

public class BubbleSortPrecios {
    public static void main(String[] args) {
        double[] precios = {33.45,56.34,22.65,43.53};
        
        for (int i = 0; i < precios.length - 1; i++){
            for (int j = 0 ; j< precios.length - 1; j++){
                if (precios[j]> precios[j+1]){
                    double temp = precios[j];
                    precios[j] = precios[j+1];
                    precios[j+1]=temp;
                }
            }
        }
        
        System.out.println("Precios ordenados");
        for (double p : precios){
            System.out.print(p + " ");
        }
    }
}
