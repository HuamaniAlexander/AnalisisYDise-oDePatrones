
package S07;

import java.util.Scanner;

public class E02CuadraticayPlegamiento {
    
    public static void main(String[] args) {
        TablaHash02 MiTablaHash= new TablaHash02(12);
        
        Scanner lector = new Scanner(System.in);
        String[] nombres = new String[12];
        int[] claves = new int[12];
        
        
        for(int i=0;i<9;i++){
        System.out.println("Ingrese Nombre:");
        nombres[i]=lector.nextLine();
        while(claves[i]<100000000 || claves[i]>999999999) {
        System.out.println("Ingese una Clave de 9 dígitos:");
        claves[i]=lector.nextInt();
        lector.nextLine();
        } 
        MiTablaHash.ingresar(claves[i], nombres[i]);
        
        }
        MiTablaHash.mostrar();
    }
}
