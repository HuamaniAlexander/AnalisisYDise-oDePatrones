package S07;

public class TablaHash02 {
    private Entry[] table;
    private int size;
    
    private static class Entry {
    int clave;
    String value;
    
    Entry(int clave, String value){
        this.clave = clave;
        this.value = value;
    }
}

    public TablaHash02(int size){
        this.size = size;
        table = new Entry[size];
    }
    
    private int FuncionPlegamiento(int clave){
        
        int parte1=clave/10000;
        int parte2=clave%10000;
        
        int suma = parte1+parte2;
        
        return suma % size;
    }
    
    public void ingresar(int clave, String value){
        int hash = FuncionPlegamiento(clave);
        int i=0;
        while (table[hash] != null){
            i++;
            hash = (FuncionPlegamiento(clave) + (i*i)) % size; 
            
            if (i>= size){
                System.out.println("La tabla está llena");
                return;
            }
        }
        table[hash] = new Entry(clave, value);
    }
    
    public void mostrar(){
        for (int i = 0; i<size; i++){
            if(table[i] != null){
                System.out.println("Posición " + i + ": " + table[i].clave + " -> " + table[i].value);
            } else {
                System.out.println("Posición " + i + ": vacía");
            }
        }
    }
    
    public void eliminar(int clave){
        int hash = FuncionPlegamiento(clave);
        int i =0;
        while (table[hash] !=null){
            if (table[hash].clave == clave){
                table[hash] = null;
                System.out.println("Elemento con clave " + clave+ " eliminado.");
                return;
            }
            i++;
            hash = (FuncionPlegamiento(clave) + (i*i)) % size;
        }
        System.out.println("Elemento con clave " + clave+" no encontrado.");
    }
    
    public void buscar(int clave){
        int hash = FuncionPlegamiento(clave);
        int i = 0;
        while (table[hash] != null){
            if (table[hash].clave == clave){
                System.out.println("Elemento: "+table[hash].value);
                return;
            }
            i++;
            hash = (FuncionPlegamiento(clave)+(i*i))%size;
        }
        System.out.println("Elemento con clave "+ clave+" no encontrado.");
    }
    
    
    
}
