package Ordenamientos;

//import java.util.Scanner;

public class Insercion {

    public static void main(String[] args) {
        int[] datos = {11,13,14,15,12};
//        int[] datos = new int[5];
//        Scanner lector = new Scanner(System.in);
//        for (int i = 0; i < 5; i++) {
//            System.out.println("Ingrese la talla:");
//            datos[i] = lector.nextInt();
//        }
        
        System.out.println("Arreglo original:");
        mostrar(datos);
        System.out.println("");
        ordenamientoPorInsercion(datos);

        System.out.println("\nArreglo ordenado:");
        mostrar(datos);
    }

    public static void ordenamientoPorInsercion(int[] arreglo) {
        int n = arreglo.length;

        for (int i = 1; i < n; i++) {
            int clave = arreglo[i];
            int j = i - 1;

            while (j >= 0 && arreglo[j] > clave) {
                arreglo[j + 1] = arreglo[j];
                j--;
            }

            arreglo[j + 1] = clave;

            System.out.print("Paso " + i + ": ");
            mostrar(arreglo);
        }
    }

    public static void mostrar(int[] arreglo) {
        for (int arr : arreglo) {
            System.out.print(arr +" ");
        }
        System.out.println();
    }
}
