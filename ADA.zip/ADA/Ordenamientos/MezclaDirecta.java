package Ordenamientos;

public class MezclaDirecta {

    public static void main(String[] args) {
        int[] datos = {34,7,23,32,5,62,32,7,23,5,62,34};

        System.out.println("Arreglo original:");
        mostrar(datos);
        ordenar(datos);
        System.out.println("\nArreglo ordenado:");
        mostrar(datos);
    }

    public static void ordenar(int[] arreglo) {
        int[] aux = new int[arreglo.length];
        int longitud = 1;
        int pasada = 1;

        while (longitud < arreglo.length) {
            System.out.println("\nPasada " + pasada);
            dividir(arreglo, longitud);
            mezclar(arreglo, aux, longitud);
            System.out.print("F: ");
            mostrar(arreglo);
            pasada++;
            longitud *= 2;
        }
    }

    public static void dividir(int[] arreglo, int longitud) {
        System.out.print("F1: ");
        for (int i = 0; i < arreglo.length; i += 2 * longitud) {
            int fin = i + longitud;
            if (fin > arreglo.length) {
                fin = arreglo.length;
            }
            for (int j = i; j < fin; j++) {
                System.out.print(arreglo[j] + " ");
            }
            System.out.print("' ");
        }
        System.out.println();

        System.out.print("F2: ");
        for (int i = longitud; i < arreglo.length; i += 2 * longitud) {
            int fin = i + longitud;
            if (fin > arreglo.length) {
                fin = arreglo.length;
            }
            for (int j = i; j < fin; j++) {
                System.out.print(arreglo[j] + " ");
            }
            System.out.print("' ");
        }
        System.out.println();
    }

    public static void mezclar(int[] arreglo, int[] aux, int longitud) {
        for (int inicio = 0; inicio < arreglo.length; inicio += 2 * longitud) {
            int medio = inicio + longitud;
            int fin = inicio + 2 * longitud;
            if (medio > arreglo.length) {
                medio = arreglo.length;
            }
            if (fin > arreglo.length) {
                fin = arreglo.length;
            }

            int i = inicio;
            int j = medio;
            int k = inicio;

            while (i < medio && j < fin) {
                if (arreglo[i] <= arreglo[j]) {
                    aux[k] = arreglo[i];
                    i++;
                } else {
                    aux[k] = arreglo[j];
                    j++;
                }
                k++;
            }

            while (i < medio) {
                aux[k] = arreglo[i];
                i++;
                k++;
            }

            while (j < fin) {
                aux[k] = arreglo[j];
                j++;
                k++;
            }

            for (int l = inicio; l < fin; l++) {
                arreglo[l] = aux[l];
            }
        }
    }

    public static void mostrar(int[] arreglo) {
        for (int arr : arreglo) {
            System.out.print(arr +" ");
        }
        System.out.println();
    }
}
