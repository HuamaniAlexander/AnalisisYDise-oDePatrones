package Ordenamientos;
public class Seleccion {

    public static void main(String[] args) {
        int[] datos = {15, 67, 8, 16, 44, 27, 12, 35};

        System.out.println("Arreglo original:");
        mostrar(datos);
        System.out.println("");
        ordenamientoPorSeleccion(datos);

        System.out.println("\nArreglo ordenado:");
        mostrar(datos);
    }

    public static void ordenamientoPorSeleccion(int[] arreglo) {
        int n = arreglo.length;

        for (int i = 0; i < n - 1; i++) {
            int min_indice = i;

            for (int j = i + 1; j < n; j++) {
                if (arreglo[j] < arreglo[min_indice]) {
                    min_indice = j;
                }
            }

            if (min_indice != i) {
                int aux = arreglo[i];
                arreglo[i] = arreglo[min_indice];
                arreglo[min_indice] = aux;
            }

            System.out.print("Paso "+ (i+1) + ": ");
            mostrar(arreglo);
        }
    }

    public static void mostrar(int[] arreglo) {
        for (int arr : arreglo) {
            System.out.print(arr +" ");
        }
        System.out.println();
    }
}
