package Ordenamientos;

import java.util.Arrays;

public class MezclaEquilibradaMultiple {

    static final int TAMANO = 2;

    public static void main(String[] args) {
        int[] datos = {8, 3, 5, 1, 9, 4, 7, 2};

        System.out.println("Lista original:");
        mostrar(datos);

        int[] resultado = ordenar(datos);

        System.out.println("\nArchivo final ordenado:");
        mostrar(resultado);
    }

    public static int[] ordenar(int[] datos) {
        int[] arreglo = Arrays.copyOf(datos, datos.length);
        int pasada = 1;

        while (!estaOrdenado(arreglo)) {
            int[][] bloques = dividir(arreglo);
            distribuir(bloques);
            arreglo = mezclar(bloques);
        }

        return arreglo;
    }

    public static int[][] dividir(int[] datos) {
        int cantidad = (int) Math.ceil((double) datos.length / TAMANO);
        int[][] bloques = new int[cantidad][];
        int k = 0;

        System.out.println("\nDivision de datos en bloques ordenados");
        for (int i = 0; i < cantidad; i++) {
            int longitud = Math.min(TAMANO, datos.length - k);
            bloques[i] = new int[longitud];
            for (int j = 0; j < longitud; j++) {
                bloques[i][j] = datos[k++];
            }
            Arrays.sort(bloques[i]);
            System.out.print("R" + (i + 1) + ": ");
            mostrar(bloques[i]);
        }

        return bloques;
    }

    public static void distribuir(int[][] bloques) {
        System.out.println("\nDistribucion en archivos de entrada");

        System.out.print("Entrada A: ");
        for (int i = 0; i < bloques.length; i += 2) {
            imprimirBloque(bloques[i]);
        }
        System.out.println();

        System.out.print("Entrada B: ");
        for (int i = 1; i < bloques.length; i += 2) {
            imprimirBloque(bloques[i]);
        }
        System.out.println();
    }

    public static int[] mezclar(int[][] bloques) {
        System.out.println("\nMezcla equilibrada");

        int cantidad = (int) Math.ceil(bloques.length / 2.0);
        int[][] salidaC = new int[cantidad][];
        int[][] salidaD = new int[cantidad][];

        int indexC = 0, indexD = 0;

        for (int i = 0; i < bloques.length; i += 2) {
            int[] a = bloques[i];
            int[] b = (i + 1 < bloques.length) ? bloques[i + 1] : new int[0];
            int[] fusion = fusionar(a, b);
            if ((i / 2) % 2 == 0) {
                salidaC[indexC++] = fusion;
            } else {
                salidaD[indexD++] = fusion;
            }
        }

        System.out.print("Salida C: ");
        for (int[] bloque : salidaC) {
            if (bloque != null) imprimirBloque(bloque);
        }
        System.out.println();

        System.out.print("Salida D: ");
        for (int[] bloque : salidaD) {
            if (bloque != null) imprimirBloque(bloque);
        }
        System.out.println();

        return fusionar(fusionarLista(salidaC), fusionarLista(salidaD));
    }

    public static int[] fusionar(int[] a, int[] b) {
        int[] r = new int[a.length + b.length];
        int i = 0, j = 0, k = 0;
        while (i < a.length && j < b.length) {
            r[k++] = (a[i] <= b[j]) ? a[i++] : b[j++];
        }
        while (i < a.length) r[k++] = a[i++];
        while (j < b.length) r[k++] = b[j++];
        return r;
    }

    public static int[] fusionarLista(int[][] bloques) {
        int[] r = new int[0];
        for (int[] b : bloques) {
            if (b != null) r = fusionar(r, b);
        }
        return r;
    }

    public static boolean estaOrdenado(int[] arreglo) {
        for (int i = 0; i < arreglo.length - 1; i++) {
            if (arreglo[i] > arreglo[i + 1]) return false;
        }
        return true;
    }

    public static void mostrar(int[] arreglo) {
        for (int val : arreglo) {
            System.out.print(val + " ");
        }
        System.out.println();
    }

    public static void imprimirBloque(int[] bloque) {
        for (int val : bloque) {
            System.out.print(val + " ");
        }
        System.out.print("' ");
    }
}
