package Ordenamientos;

import java.util.ArrayList;
import java.util.List;

public class FusionNatural {

    public static void main(String[] args) {
        int[] datos = {34,7,23,32,5,62,32,7,23,5,62,34};

        System.out.println("Arreglo original:");
        mostrar(datos);
        fusionNatural(datos);
        System.out.println("\nArreglo ordenado:");
        mostrar(datos);
    }

    public static void fusionNatural(int[] arreglo) {
        int[] aux = new int[arreglo.length];
        int pasada = 1;

        while (true) {
            List<int[]> bloques = dividirSecuencias(arreglo);
            if (bloques.size() == 1) {
                break;
            }

            System.out.println("\nPasada " + pasada);
            System.out.print("F1: ");
            for (int i = 0; i < bloques.size(); i += 2) {
                for (int val : bloques.get(i)) {
                    System.out.print(val + " ");
                }
                System.out.print("' ");
            }
            System.out.println();

            System.out.print("F2: ");
            for (int i = 1; i < bloques.size(); i += 2) {
                for (int val : bloques.get(i)) {
                    System.out.print(val + " ");
                }
                System.out.print("' ");
            }
            System.out.println();

            unir(bloques, aux, arreglo);
            System.out.print("F: ");
            mostrar(arreglo);
            pasada++;
        }
    }

    public static List<int[]> dividirSecuencias(int[] arreglo) {
        List<int[]> bloques = new ArrayList<>();
        int inicio = 0;

        while (inicio < arreglo.length) {
            int fin = inicio + 1;
            while (fin < arreglo.length && arreglo[fin - 1] <= arreglo[fin]) {
                fin++;
            }
            int[] bloque = new int[fin - inicio];
            for (int i = inicio; i < fin; i++) {
                bloque[i - inicio] = arreglo[i];
            }
            bloques.add(bloque);
            inicio = fin;
        }

        return bloques;
    }

    public static void unir(List<int[]> bloques, int[] aux, int[] destino) {
        int k = 0;
        for (int i = 0; i < bloques.size(); i += 2) {
            int[] a = bloques.get(i);
            int[] b = (i + 1 < bloques.size()) ? bloques.get(i + 1) : new int[0];
            int i1 = 0, i2 = 0;

            while (i1 < a.length && i2 < b.length) {
                aux[k++] = (a[i1] <= b[i2]) ? a[i1++] : b[i2++];
            }
            while (i1 < a.length) {
                aux[k++] = a[i1++];
            }
            while (i2 < b.length) {
                aux[k++] = b[i2++];
            }
        }

        for (int i = 0; i < destino.length; i++) {
            destino[i] = aux[i];
        }
    }

    public static void mostrar(int[] arreglo) {
        for (int arr : arreglo) {
            System.out.print(arr +" ");
        }
        System.out.println();
    }
}
