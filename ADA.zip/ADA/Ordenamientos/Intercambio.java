package Ordenamientos;

public class Intercambio {
    public static void main(String[] args) {
        int[] datos = {15,67,8,16,44,27};

        System.out.println("Arreglo original:");
        mostrar(datos);
        System.out.println("");
        ordenamientoBurbuja(datos);

        System.out.println("\nArreglo ordenado:");
        mostrar(datos);
    }

    public static void ordenamientoBurbuja(int[] arreglo) {
        int n = arreglo.length;

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (arreglo[j] > arreglo[j + 1]) {
                    int aux = arreglo[j];
                    arreglo[j] = arreglo[j + 1];
                    arreglo[j + 1] = aux;
                }
            }
            System.out.print("Paso " + (i + 1) + ": ");
            mostrar(arreglo);
        }
    }

    public static void mostrar(int[] arreglo) {
        for (int valor : arreglo) {
            System.out.print(valor + " ");
        }
        System.out.println();
    }
}