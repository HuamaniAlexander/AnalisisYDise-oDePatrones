package Ordenamientos;
import java.util.*;

public class MezclaPolifasica {

    public static void main(String[] args) {
        int[] datos = {34, 7, 23, 32, 5, 62, 32, 7};
        System.out.println("Lista original: " + Arrays.toString(datos));
        int[] resultado = ordenarPolifasico(datos);
        System.out.println("Resultado final: " + Arrays.toString(resultado));
    }

    public static int[] ordenarPolifasico(int[] datos) {
        int tamanoGrupoInicial = 2; // cambiar aca por el que se desea
        List<List<Integer>> secuencias = new ArrayList<>();

        System.out.println("PASO 1: Division");
        for (int i = 0; i < datos.length; i += tamanoGrupoInicial) {
            List<Integer> sec = new ArrayList<>();
            for (int j = 0; j < tamanoGrupoInicial && (i + j) < datos.length; j++) {
                sec.add(datos[i + j]);
            }
            Collections.sort(sec);
            secuencias.add(sec);
            System.out.println("Secuencia " + secuencias.size() + ": " + sec);
        }

        List<List<Integer>> A = new ArrayList<>();
        List<List<Integer>> B = new ArrayList<>();
        List<List<Integer>> C = new ArrayList<>();

        System.out.println("PASO 2: Distribucion");
        distribuirEnArchivos(secuencias, A, B, C);
        mostrar(A, B, C);

        int paso = 3;
        while (A.size() + B.size() + C.size() > 2) {
            System.out.println("PASO " + paso + ": Mezcla");
            C.clear();
            int min = Math.min(A.size(), B.size());

            for (int i = 0; i < min; i++) {
                C.add(mezclar(A.get(i), B.get(i)));
            }

            for (int i = min; i < A.size(); i++) {
                C.add(new ArrayList<>(A.get(i)));
            }

            A.clear();
            B.clear();
            mostrar(A, B, C);
            paso++;

            if (C.size() > 2) {
                System.out.println("PASO " + paso + ": Rotacion");
                distribuirEnArchivos(C, A, B, new ArrayList<>());
                C.clear();
                mostrar(A, B, C);
                paso++;
            }
        }

        System.out.println("Mezcla final");
        List<Integer> primera = obtenerPrimera(A, B, C);
        List<Integer> segunda = obtenerSegunda(A, B, C);
        List<Integer> resultado = mezclar(primera, segunda);

        return resultado.stream().mapToInt(Integer::intValue).toArray();
    }

    static void distribuirEnArchivos(List<List<Integer>> origen, List<List<Integer>> A, List<List<Integer>> B, List<List<Integer>> C) {
        int total = origen.size();
        int[] distribucion = distribuirFibonacci(total);
        int numA = distribucion[0];
        int numB = distribucion[1];
        int numC = distribucion[2];

        for (int i = 0; i < numA && i < total; i++) {
            A.add(new ArrayList<>(origen.get(i)));
        }
        for (int i = numA; i < numA + numB && i < total; i++) {
            B.add(new ArrayList<>(origen.get(i)));
        }
        for (int i = numA + numB; i < total; i++) {
            C.add(new ArrayList<>(origen.get(i)));
        }
    }

    static int[] distribuirFibonacci(int totalCorridas) {
        if (totalCorridas <= 1) return new int[]{totalCorridas, 0, 0};
        if (totalCorridas == 2) return new int[]{1, 1, 0};

        List<Integer> fibonacci = new ArrayList<>(Arrays.asList(0, 1, 1));
        while (fibonacci.get(fibonacci.size() - 1) < totalCorridas) {
            int next = fibonacci.get(fibonacci.size() - 1) + fibonacci.get(fibonacci.size() - 2);
            fibonacci.add(next);
        }

        int k = fibonacci.size() - 1;
        while (k >= 3 && fibonacci.get(k) > totalCorridas) k--;

        int mayor = fibonacci.get(k - 1);
        int menor = fibonacci.get(k - 2);
        int faltantes = totalCorridas - (mayor + menor);
        mayor += faltantes;

        return new int[]{mayor, menor, 0};
    }

    static List<Integer> mezclar(List<Integer> a, List<Integer> b) {
        List<Integer> resultado = new ArrayList<>();
        int i = 0, j = 0;

        while (i < a.size() && j < b.size()) {
            if (a.get(i) <= b.get(j)) {
                resultado.add(a.get(i++));
            } else {
                resultado.add(b.get(j++));
            }
        }

        while (i < a.size()) resultado.add(a.get(i++));
        while (j < b.size()) resultado.add(b.get(j++));

        return resultado;
    }

    static void mostrar(List<List<Integer>> A, List<List<Integer>> B, List<List<Integer>> C) {
        System.out.println("Archivo A: " + (A.isEmpty() ? "vacio" : A));
        System.out.println("Archivo B: " + (B.isEmpty() ? "vacio" : B));
        System.out.println("Archivo C: " + (C.isEmpty() ? "vacio" : C));
        System.out.println();
    }

    static List<Integer> obtenerPrimera(List<List<Integer>> A, List<List<Integer>> B, List<List<Integer>> C) {
        if (!A.isEmpty()) return A.get(0);
        if (!B.isEmpty()) return B.get(0);
        if (!C.isEmpty()) return C.get(0);
        return new ArrayList<>();
    }

    static List<Integer> obtenerSegunda(List<List<Integer>> A, List<List<Integer>> B, List<List<Integer>> C) {
        if (A.size() > 1) return A.get(1);
        if (A.size() == 1 && !B.isEmpty()) return B.get(0);
        if (A.size() == 1 && !C.isEmpty()) return C.get(0);
        if (A.isEmpty() && !B.isEmpty()) return B.get(0);
        if (C.size() > 1) return C.get(1);
        return new ArrayList<>();
    }
}
