package Semana08;

public class BuscarConIndice {

    public static void main(String[] args){
        
        int[] archivo = {15, 26, 76, 24, 36, 45, 81, 43, 28, 19, 14, 55, 99, 78, 62, 88, 47, 83, 72, 68, 49};
        
        int datoBuscado = 68;
        int bpi = BuscarConIndice(archivo, datoBuscado);
        
        if (bpi != -1){
            System.out.println("\nSe encontro el numero " + datoBuscado + " en la posicion: " + bpi);
        } else {
            System.out.println("\nNo se encontro el numero");
        }

    }
    
    public static int BuscarConIndice(int[] archivo, int datoBuscado){
         
        int indice = 0;
        
        System.out.println("Iniciando busqueda del numero " + datoBuscado + "...\n");
        
        while (indice < archivo.length){
            
            System.out.println("Comparando indice " + indice + ": valor " + archivo[indice]);
            
            if (archivo[indice] == datoBuscado){
                System.out.println("Coincidencia encontrada en el indice " + indice);
                return indice;
            }
            
            indice++;
        }
        
        System.out.println("\nRevision completa. El numero no esta en el arreglo.");
        return -1;
    }
}
