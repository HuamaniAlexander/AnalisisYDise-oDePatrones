package Semana08;

public class BXB_letras {

    public static void main(String[] args) {
        
        String[] nombres = {"Juan", "Johana", "Paul", "Julia", "Pablo", "Roberto", "Cinthia", "Maria", "Meury", "Pamela"};
        int tamanoBloque = 3;
        String datoBuscado = "Maria";
        
        String resultado = BuscarXBloque(nombres, datoBuscado, tamanoBloque);
        
        if (resultado != null) {
            System.out.println("\nEl nombre " + resultado + " fue encontrado.");
        } else {
            System.out.println("\nNo se encontro el nombre en ningun bloque.");
        }
    }
    
    public static String BuscarXBloque(String[] nombres, String datoBuscado, int tamanoBloque) {
        
        int i = 0;
        int bloque = 0;
        
        System.out.println("Iniciando busqueda del nombre " + datoBuscado + " por bloques...\n");
        
        while (i < nombres.length) {
            bloque++;
            System.out.println("Revisando bloque " + bloque);
            
            for (int j = 0; j < tamanoBloque; j++) {
                if (i >= nombres.length) break;
                
                System.out.println("Comparando indice " + i + ": " + nombres[i]);
                
                if (nombres[i].equalsIgnoreCase(datoBuscado)) {
                    System.out.println("Coincidencia encontrada en el bloque " + bloque + ", indice " + i);
                    return nombres[i];
                }
                i++;
            }
            
            System.out.println("No se encontro el nombre en el bloque " + bloque + "\n");
        }
        
        System.out.println("Revision completa. El nombre no esta en ningun bloque.");
        return null;
    }
}
