package Semana08;

public class BCI_letras {

    public static void main(String[] args) {
        
        String[] nombres = {"Juan", "Johana", "Paul", "Julia", "Pablo", "Roberto", "Cinthia", "Maria", "Meury", "Pamela"};
        
        String datoBuscado = "Maria";
        int bpi = BuscarConIndice(nombres, datoBuscado);
        
        if (bpi != -1) {
            System.out.println("\nSe encontro el nombre " + datoBuscado + " en la posicion: " + bpi);
        } else {
            System.out.println("\nNo se encontro el nombre");
        }
    }
    
    public static int BuscarConIndice(String[] nombres, String datoBuscado) {
        
        int indice = 0;
        
        System.out.println("Iniciando busqueda del nombre " + datoBuscado + "...\n");
        
        while (indice < nombres.length) {
            
            System.out.println("Comparando indice " + indice + ": valor " + nombres[indice]);
            
            if (nombres[indice].equalsIgnoreCase(datoBuscado)) {
                System.out.println("Coincidencia encontrada en el indice " + indice);
                return indice;
            }
            
            indice++;
        }
        
        System.out.println("\nRevision completa. El nombre no esta en el arreglo.");
        return -1;
    }
}
