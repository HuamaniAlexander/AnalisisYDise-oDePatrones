package Semana08;

public class BuscarXBloque {

    public static void main(String[] args){
        
        int[] archivo = {15, 26, 76, 24, 36, 45, 81, 43, 28, 19, 14, 55, 99, 78, 62, 88, 47, 83, 72, 68, 49};
        int tamano = 5;
        
        int resultado = BuscarXBloque(archivo, 68, tamano);
        
        if (resultado != -1) {
            System.out.println("El numero " + resultado + " fue encontrado.");
        } else {
            System.out.println("No se encontro el numero en ningun bloque.");
        }
    }
    
    public static int BuscarXBloque(int[] archivo, int datoBuscado, int tamaño){
         
        int i = 0;
        int bloque = 0;
        
        System.out.println("Iniciando busqueda del numero " + datoBuscado + " por bloques...\n");
        
        while (i < archivo.length){
            bloque++;
            System.out.println("Revisando bloque " + bloque);
            
            for (int j = 0; j < tamaño; j++){
                if (i >= archivo.length) break;
                
                System.out.println("Comparando indice " + i + ": valor " + archivo[i]);
                
                if (archivo[i] == datoBuscado){
                    System.out.println("Coincidencia encontrada en el bloque " + bloque + ", indice " + i);
                    return archivo[i];
                }
                i++;
            }
            
            System.out.println("No se encontro el numero en el bloque " + bloque + "\n");
        }
        
        System.out.println("Revision completa. El numero no esta en ningun bloque.");
        return -1;
    }
}
