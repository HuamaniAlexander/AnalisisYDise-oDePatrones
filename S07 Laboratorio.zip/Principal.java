package Ejercicios;

public class Principal {
    public static void main(String[] args) {
        TablaHash MiTablaHash= new TablaHash(11);
        MiTablaHash.ingresar(100, "Juan");
        MiTablaHash.ingresar(102, "Jorge");
        MiTablaHash.ingresar(303, "Maria");
        MiTablaHash.ingresar(132, "Juana");
        MiTablaHash.ingresar(133, "Johana");
        MiTablaHash.ingresar(134, "Julio");
        MiTablaHash.ingresar(135, "Patty");
        MiTablaHash.ingresar(136, "Pedro");
        MiTablaHash.ingresar(137, "Antonio");
        MiTablaHash.ingresar(138, "Julia");
        MiTablaHash.ingresar(139, "Mary");
        
        MiTablaHash.mostrar();
        
        MiTablaHash.eliminar(135);
        MiTablaHash.buscar(139);
        MiTablaHash.buscar(135);
        
    }
    
    
}
